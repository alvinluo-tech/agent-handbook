// 验证补录候选 ID + 标题检索 Terminal-Bench / MCP security
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clean = (s) => (s || '').replace(/\s+/g, ' ').trim();
(async () => {
  const ids = ['2503.13657', '2503.09516', '2409.07429', '2402.17753', '2405.14573', '2504.11030', '2504.03160'];
  let xml = await (await fetch(`http://export.arxiv.org/api/query?id_list=${ids.join(',')}&max_results=10`)).text();
  console.log('== 按 ID 验证 ==');
  for (const e of xml.split('<entry>').slice(1)) {
    const id = (e.match(/abs\/([^<]+)<\/id>/) || [])[1];
    const title = clean(e.match(/<title>([\s\S]*?)<\/title>/)?.[1]);
    console.log(`${id} | ${title.slice(0, 110)}`);
  }
  await sleep(1200);
  console.log('\n== 标题检索 ==');
  for (const q of ['Terminal-Bench Benchmarking Agents on Hard Realistic Tasks in Command Line', 'Agent Workflow Memory']) {
    const u = `http://export.arxiv.org/api/query?search_query=ti:%22${encodeURIComponent(q).replace(/%20/g, '+')}%22&max_results=3`;
    const x = await (await fetch(u)).text();
    for (const e of x.split('<entry>').slice(1)) {
      const id = (e.match(/abs\/([^<]+)<\/id>/) || [])[1];
      const title = clean(e.match(/<title>([\s\S]*?)<\/title>/)?.[1]);
      console.log(`${id} | ${title.slice(0, 110)}`);
    }
    console.log('---');
    await sleep(1200);
  }
})();
