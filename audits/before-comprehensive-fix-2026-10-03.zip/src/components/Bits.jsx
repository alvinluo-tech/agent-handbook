import { useEffect, useRef, useState } from 'react'

/* ---------- 章节头 ---------- */
export function ChapterHead({ num, icon, title, en, mins }) {
  return (
    <div className="ch-head">
      <div className="ch-meta">
        <span className="ch-level">{num}</span>
        <span className="ch-mins">⏱ 约 {mins} 分钟 · {icon}</span>
      </div>
      <h2 className="ch-title">{title}</h2>
      <div className="ch-en">{en}</div>
    </div>
  )
}

/* ---------- 通关清单(存 localStorage,驱动 LV/EXP) ---------- */
export function QuestList({ id, items }) {
  const [checks, setChecks] = useState(() => {
    try { return JSON.parse(localStorage.getItem('adg-quests') || '{}') } catch { return {} }
  })
  const done = new Set(checks[id] || [])
  const toggle = (i) => {
    const next = { ...checks, [id]: done.has(i) ? (checks[id] || []).filter((x) => x !== i) : [...(checks[id] || []), i] }
    setChecks(next)
    localStorage.setItem('adg-quests', JSON.stringify(next))
    window.dispatchEvent(new Event('adg-quest-change'))
  }
  return (
    <div className="quest">
      <div className="quest-head">
        <span>◆ 本章通关清单</span>
        <span className="quest-count">{done.size}/{items.length} DONE</span>
      </div>
      <ul className="quest-list">
        {items.map((t, i) => (
          <li key={i}>
            <label className={`quest-item ${done.has(i) ? 'done' : ''}`}>
              <input type="checkbox" style={{ display: 'none' }} checked={done.has(i)} onChange={() => toggle(i)} />
              <span className="box">{done.has(i) ? '✔' : ''}</span>
              <span>{t}</span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  )
}

/* ---------- 通用章节骨架 ---------- */
export function Chapter({ ch, children }) {
  return (
    <>
      <ChapterHead {...ch} />
      {children}
      <QuestList id={ch.id} items={ch.quests} />
    </>
  )
}

/* ---------- Agent 循环交互演示终端 ---------- */
const SCRIPT = [
  { cls: 'in', text: 'user > 我们下月要办 Agent 技术分享会,帮我看看仓库 agent-guide 还有多少 open issue,顺便给 issues 打上 "meetup" 标签。' },
  { cls: 'dim', text: '[LOOP 1 · 感知] 读取用户目标 + 当前上下文…' },
  { cls: 'out', text: 'thought > 目标有两个:①统计 open issue 数 ②打标签。我需要先调用 GitHub 工具列出 issues。' },
  { cls: 'tool', text: 'action > call list_issues(repo="org/agent-guide", state="open")' },
  { cls: 'dim', text: '[环境执行] GitHub API 返回 → 42 条记录(用时 380ms)' },
  { cls: 'out', text: 'observation > open issues = 42。接下来给它们打标签。' },
  { cls: 'tool', text: 'action > call add_label(repo="org/agent-guide", issue="all", label="meetup")' },
  { cls: 'err', text: 'observation > ✗ 权限不足:批量写操作需要人工确认(权限策略:write:batch)' },
  { cls: 'out', text: 'thought > 写操作被 human-in-the-loop 拦截。我应该请求用户授权,而不是反复重试。' },
  { cls: 'tool', text: 'action > ask_human("将为 42 个 open issue 添加标签 meetup,确认执行?")' },
  { cls: 'in', text: 'user > 确认,执行吧。' },
  { cls: 'tool', text: 'action > call add_label(...) → 42/42 成功' },
  { cls: 'dim', text: '[LOOP 2 · 反思] 子目标全部完成,可以终止循环。' },
  { cls: 'out', text: 'final > 仓库共有 42 个 open issue,已全部打上 "meetup" 标签 ✔(中途经历 1 次权限拦截,经你确认后完成)。' },
]

export function LoopDemo() {
  const [n, setN] = useState(0)
  const timer = useRef(null)
  const play = () => {
    if (timer.current) return
    timer.current = setInterval(() => {
      setN((v) => {
        if (v >= SCRIPT.length) { clearInterval(timer.current); timer.current = null; return v }
        return v + 1
      })
    }, 900)
  }
  useEffect(() => () => clearInterval(timer.current), [])
  const reset = () => { clearInterval(timer.current); timer.current = null; setN(0) }
  return (
    <div className="term">
      <div className="term-bar">
        <span style={{ color: '#f27e7e' }}>●</span>
        <span style={{ color: '#f2d87e' }}>●</span>
        <span style={{ color: '#7ef29d' }}>●</span>
        <span style={{ marginLeft: 8 }}>AGENT_LOOP.SIM — {n < SCRIPT.length ? 'RUNNING' : 'COMPLETE'}</span>
      </div>
      <div className="term-body">
        {SCRIPT.slice(0, n).map((s, i) => (
          <div key={i} className={s.cls}>{s.text}</div>
        ))}
        {n < SCRIPT.length && <div className="dim">▌</div>}
      </div>
      <div style={{ padding: '0 18px 14px', display: 'flex', gap: 10 }}>
        <button className="px-btn" style={{ fontSize: 12, padding: '6px 14px' }} onClick={play} disabled={n >= SCRIPT.length}>▶ 自动运行</button>
        <button className="px-btn blue" style={{ fontSize: 12, padding: '6px 14px' }} onClick={() => { clearInterval(timer.current); timer.current = null; setN((v) => Math.min(SCRIPT.length, v + 1)) }}>⏭ 单步</button>
        <button className="px-btn ghost" style={{ fontSize: 12, padding: '6px 14px' }} onClick={reset}>↺ 重置</button>
      </div>
    </div>
  )
}

/* ---------- 手风琴(FAQ 用) ---------- */
export function Acc({ q, children }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="faq">
      <q onClick={() => setOpen((v) => !v)} style={{ cursor: 'pointer' }}>
        <span style={{ color: 'var(--accent)', marginRight: 8 }}>{open ? '▼' : '▶'}</span>{q}
      </q>
      {open && <p>{children}</p>}
    </div>
  )
}
