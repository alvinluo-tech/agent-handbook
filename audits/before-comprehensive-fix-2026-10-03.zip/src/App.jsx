import { useEffect, useMemo, useRef, useState, useCallback, lazy, Suspense } from 'react'
import { CHAPTERS, EXTRAS } from './chapters/index.js'
import RobotSprite from './components/RobotSprite.jsx'
import LabsPage from './chapters/labs/LabsPage.jsx'
import { LABS } from './chapters/labs/registry.js'
import resourceSummary from './data/resource-summary.json'

// 大数据页面按需加载；首页只读取轻量资源摘要。
const PapersPage = lazy(() => import('./chapters/PapersPage.jsx'))
const ProjectsPage = lazy(() => import('./chapters/ProjectsPage.jsx'))

export function readChecks() {
  try { return JSON.parse(localStorage.getItem('adg-quests') || '{}') } catch { return {} }
}

export default function App() {
  const [view, setView] = useState('home')
  const [activeId, setActiveId] = useState('')
  const [progress, setProgress] = useState(0)
  const [navOpen, setNavOpen] = useState(false)
  const [checks, setChecks] = useState(readChecks)
  const questChange = useCallback(() => setChecks(readChecks()), [])

  useEffect(() => {
    window.addEventListener('adg-quest-change', questChange)
    const go = (e) => goViewRef.current(e.detail)
    window.addEventListener('adg-go', go)
    return () => {
      window.removeEventListener('adg-quest-change', questChange)
      window.removeEventListener('adg-go', go)
    }
  }, [questChange])

  // 滚动:进度条 + 侧边栏 scrollspy
  useEffect(() => {
    const onScroll = () => {
      const doc = document.documentElement
      const max = doc.scrollHeight - window.innerHeight
      setProgress(max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0)
      if (view !== 'home') return
      const markers = document.querySelectorAll('[data-ch]')
      let cur = ''
      markers.forEach((el) => { if (el.getBoundingClientRect().top < 150) cur = el.dataset.ch })
      setActiveId(cur)
    }
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [view])

  const pendingScroll = useRef(null)
  // 视图切换:默认回顶;若携带章节目标则精准定位(避免平滑滚动与复位竞争)
  useEffect(() => {
    if (view !== 'home') { window.scrollTo({ top: 0, behavior: 'instant' }); return }
    const id = pendingScroll.current
    if (id) {
      pendingScroll.current = null
      requestAnimationFrame(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'instant', block: 'start' })
      })
    } else {
      window.scrollTo({ top: 0, behavior: 'instant' })
    }
  }, [view])

  const goChapter = (id) => {
    setNavOpen(false)
    if (view === 'home') {
      document.getElementById(id)?.scrollIntoView({ behavior: 'instant', block: 'start' })
    } else {
      pendingScroll.current = id
      setView('home')
    }
  }

  const goView = (v) => { setView(v); setNavOpen(false) }
  const goViewRef = useRef(goView)
  goViewRef.current = goView

  // EXP / 等级:由通关清单勾选数决定(主线章节 + 实战工坊)
  const { totalQuests, doneQuests, lv, lvName, expPct } = useMemo(() => {
    let total = 0, done = 0
    for (const ch of CHAPTERS) {
      const set = new Set(checks[ch.id] || [])
      total += ch.quests.length
      done += ch.quests.filter((_, i) => set.has(i)).length
    }
    for (const lab of LABS) {
      const set = new Set(checks[lab.qid] || [])
      total += lab.quests.length
      done += lab.quests.filter((_, i) => set.has(i)).length
    }
    const lv = Math.min(10, Math.floor(done / Math.max(1, total / 10)) + (done > 0 ? 1 : 0))
    const names = ['新手村民', '见习冒险者', '学徒工程师', 'Prompt 见习生', '工具使', '循环驭手', '架构骑士', 'Eval 贤者', '多智能体公爵', 'Agent 大师']
    return {
      totalQuests: total, doneQuests: done, lv,
      lvName: total > 0 && done === total ? '★ Agent 大师(满级!)' : names[lv - 1] || names[0],
      expPct: total ? (done / total) * 100 : 0,
    }
  }, [checks])

  const extraDefs = [
    { key: 'labs', icon: '🔨', label: '实战工坊', sub: 'LB' },
    { key: 'papers', icon: '📚', label: '论文军火库', sub: 'PA' },
    { key: 'projects', icon: '⚔️', label: 'GitHub 兵器谱', sub: 'GH' },
    { key: 'roadmap', icon: '🗺️', label: '进化路线图', sub: 'RM' },
    { key: 'glossary', icon: '🎴', label: '术语图鉴 & FAQ', sub: 'GL' },
  ]

  return (
    <>
      <div className="progress-track"><div className="progress-fill" style={{ width: `${progress}%` }} /></div>
      <button className="nav-toggle" aria-label="目录" onClick={() => setNavOpen((v) => !v)}>☰</button>

      <aside className={`sidebar ${navOpen ? 'open' : ''}`}>
        <div className="sidebar-head">
          <div className="logo-row">
            <div className="logo-bot"><RobotSprite /></div>
            <div>
              <div className="logo-title">AGENT 开发全指南</div>
              <div className="logo-sub">FROM ZERO TO AGENT MASTER</div>
            </div>
          </div>
        </div>

        <div className="lv-box">
          <div className="lv-line">
            <span className="lv-num">LV.{lv}</span>
            <span className="lv-name">{lvName}</span>
          </div>
          <div className="exp-track"><div className="exp-fill" style={{ width: `${expPct}%` }} /></div>
          <div className="exp-hint">EXP {doneQuests}/{totalQuests} · 完成各章「通关清单」涨经验</div>
        </div>

        <nav className="toc">
          <div className="toc-label">— 主线攻略 —</div>
          {CHAPTERS.map((ch) => (
            <button key={ch.id} className={`toc-item ${view === 'home' && activeId === ch.id ? 'active' : ''}`} onClick={() => goChapter(ch.id)}>
              <span className="toc-num">{ch.num}</span>
              <span className="toc-ico">{ch.icon}</span>
              <span>{ch.title}</span>
              {ch.quests.length > 0 && (checks[ch.id] || []).length >= ch.quests.length && <span className="toc-check">✔</span>}
            </button>
          ))}
          <div className="toc-label">— 支线副本 —</div>
          {extraDefs.map((e) => (
            <button key={e.key} className={`toc-item special ${view === e.key ? 'active' : ''}`} onClick={() => goView(e.key)}>
              <span className="toc-num">{e.sub}</span>
              <span className="toc-ico">{e.icon}</span>
              <span>{e.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-foot">
          持续更新 · 数据截至 2026-10<br />
          论文 {resourceSummary.papers} 篇 · 项目 {resourceSummary.projects} 个 · 实战项目 {LABS.length} 个
        </div>
      </aside>

      <main className="main">
        {view === 'home' && <HomeView goChapter={goChapter} />}
        {view === 'labs' && <LabsPage />}
        {view === 'papers' && <Suspense fallback={<div className="page" style={{ color: 'var(--ink-faint)' }}>📦 打开论文军火库…</div>}><PapersPage /></Suspense>}
        {view === 'projects' && <Suspense fallback={<div className="page" style={{ color: 'var(--ink-faint)' }}>⚔️ 打开兵器谱…</div>}><ProjectsPage /></Suspense>}
        {view === 'roadmap' && <EXTRAS.roadmap />}
        {view === 'glossary' && <EXTRAS.glossary />}
        <footer className="foot">
          <div className="foot-inner">
            <div><b style={{ color: 'var(--gold)' }}>AGENT 开发全指南</b> — 一本写给未来 Agent 工程师的像素风手册</div>
            <div>内容核查快照：2026-10-03。版本、价格与协议状态均有适用日期；后续变化以官方来源为准。构建: React + Vite · 字体: Press Start 2P / Fusion Pixel <span className="pixel-heart">♥</span></div>
            <div className="foot-8bit">PRESS [START] TO CONTINUE YOUR JOURNEY... GAME OVER? NO — GAME ON!</div>
          </div>
        </footer>
      </main>
    </>
  )
}

function HomeView({ goChapter }) {
  return (
    <>
      <header className="hero hero-crt">
        <span className="hero-tag">◆ VERSION 1.1 · 核查快照 2026-10-03 · AGENT 工程师养成</span>
        <h1>AGENT 开发工程师<br /><span className="hl">全指南</span></h1>
        <p className="lead">
          一本<strong style={{ color: 'var(--gold)' }}>像素风互动手册</strong>,从「什么是 Agent」一路打到「多智能体架构、协议生态与前沿方向」。
          知识点全部对照 2025-2026 一线大厂公开实践(Anthropic / OpenAI / Google / 微软)与经典论文整理,
          配备流程图、可运行的循环演示、通关清单、论文军火库与 GitHub 兵器谱——
          <b style={{ color: 'var(--term-cyan)' }}>目标只有一个:小白通关,行业大师存档。</b>
        </p>
        <div className="hero-stats">
          <div className="hero-stat"><b>19</b><span>主线章节</span></div>
          <div className="hero-stat"><b>{resourceSummary.diagrams}</b><span>原创图解</span></div>
          <div className="hero-stat"><b>3</b><span>实战教学项目</span></div>
          <div className="hero-stat"><b>{resourceSummary.papers}</b><span>归类论文</span></div>
          <div className="hero-stat"><b>68</b><span>高星项目</span></div>
          <div className="hero-stat"><b>∞</b><span>搞 Agent 的热情</span></div>
        </div>
        <button className="px-btn" style={{ marginTop: 30 }} onClick={() => goChapter('ch01')}>▶ 按下 START,开始冒险</button>
        <div className="hero-deco"><RobotSprite big /></div>
      </header>

      <div className="page" style={{ paddingTop: 40, paddingBottom: 0 }}>
        <div className="card gold" style={{ marginTop: 30 }}>
          <span className="card-tag">如何使用本手册</span>
          <ul style={{ margin: '4px 0 0' }}>
            <li>左侧是<strong>主线攻略顺序</strong>,由浅入深;完全零基础请按顺序推进,有经验的玩家可直接空降章节。</li>
            <li>想动手?<strong>「实战工坊」</strong>有三个教学项目(客服 Agent / 深度研究 / 代码审查)，提供关键代码、架构决策与评测设计。补齐集成后验证，简历只写自己完成并测得的结果。</li>
            <li>每章末尾有<strong>「通关清单」</strong>——勾选后侧边栏 LV 会涨经验(实战项目同样计分),集齐全部徽章成为满级 Agent 大师。</li>
            <li>看到 <span className="tag a">实战</span> <span className="tag g">洞察</span> <span className="tag p">避坑</span> 标签的卡片,是浓缩的实战经验,值得背下来。</li>
            <li>外部资料链接指向原文；论文 PDF 本地提供。项目 Star 与更新时间是 GitHub API 采集快照，归档项目另标历史参考。</li>
          </ul>
        </div>
      </div>

      {CHAPTERS.map(({ id, Comp }) => (
        <section key={id} id={id} data-ch={id} className="chapter">
          <Comp />
        </section>
      ))}
    </>
  )
}
