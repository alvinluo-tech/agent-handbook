import { FigRoadmap } from '../components/Diag2.jsx'

export default function RoadmapPage() {
  return (
    <div className="page">
      <div className="page-head">
        <div className="ch-meta">
          <span className="ch-level">EXTRA · 支线</span>
          <span className="ch-mins">🗺️ 12 周计划 · 每天 1-2 小时</span>
        </div>
        <h2 className="ch-title">小白进化路线图</h2>
        <div className="ch-en">LEVEL-UP ROADMAP — ZERO TO AGENT MASTER</div>
      </div>

      <FigRoadmap />

      <div className="card gold" style={{ marginTop: 26 }}>
        <span className="card-tag">总原则</span>
        ① <strong>项目制学习</strong>:每一阶段以「做出东西」为里程碑,不以「看完视频」为里程碑;② <strong>读懂论文摘要即可动手</strong>,卡住再精读;③ 每周固定时间复盘:本周做的 agent 哪里翻车了?翻车点通常就是下一周该学的知识点。
      </div>

      <div className="road-grid">
        <div className="road-phase">
          <div className="ph-head"><span>第 1-2 周 · 打地基</span><span className="lv">LV.1-2</span></div>
          <ul>
            <li>通读本书 CH.01-04,跑通 CH.02/05 的 API 代码</li>
            <li><b>项目①</b>:命令行聊天机器人(流式输出 + token 统计)</li>
            <li>精读:Attention Is All You Need(可只读引言+图)、ReAct</li>
            <li>刷:Anthropic《Building Effective Agents》</li>
          </ul>
        </div>
        <div className="road-phase">
          <div className="ph-head"><span>第 3-5 周 · 造循环</span><span className="lv">LV.3-4</span></div>
          <ul>
            <li>CH.03/05/06:手写 Agent Loop → 加工具 → 接 MCP</li>
            <li><b>项目②</b>:「研究员 agent」——搜网页+读文件+写 markdown 报告</li>
            <li>装一个 MCP server(如 filesystem),让 Claude/Cursor 用上</li>
            <li>读 smolagents 源码(1k 行,一晚上能读完)</li>
          </ul>
        </div>
        <div className="road-phase">
          <div className="ph-head"><span>第 6-8 周 · 上强度</span><span className="lv">LV.5-7</span></div>
          <ul>
            <li>CH.07-10:沙箱、框架、记忆、RAG 各完成一次最小实践</li>
            <li><b>项目③</b>:给项目②加「记忆 + RAG 知识库 + 沙箱跑代码」</li>
            <li>选定主框架(LangGraph / OpenAI SDK / Mastra)重写项目③,对比体会</li>
            <li>精读:MemGPT、SWE-bench、GAIA</li>
          </ul>
        </div>
        <div className="road-phase">
          <div className="ph-head"><span>第 9-10 周 · 学会度量</span><span className="lv">LV.8</span></div>
          <ul>
            <li>CH.15/17:给项目③建 50 条黄金任务集 + promptfoo CI</li>
            <li><b>项目④</b>:用 eval 驱动把项目③的完成率提升 15 个点</li>
            <li>接入 Langfuse,学会读 trace、算成本</li>
          </ul>
        </div>
        <div className="road-phase">
          <div className="ph-head"><span>第 11-12 周 · 成大师</span><span className="lv">LV.9-10</span></div>
          <ul>
            <li>CH.12/13/14/16/18/19:多智能体、安全、协议各过一遍</li>
            <li><b>毕业项目⑤</b>:多 agent 协作系统(如「自动调研+写作+审稿」流水线),含沙箱、权限闸门、评估看板</li>
            <li>给项目写一篇复盘博客/做一次分享——输出是最后 10% 的学习</li>
          </ul>
        </div>
        <div className="road-phase">
          <div className="ph-head"><span>毕业之后</span><span className="lv">NEW GAME+</span></div>
          <ul>
            <li>跟进:每月挑 1 篇新论文 + 1 个新框架 release notes</li>
            <li>深耕:选一个垂直方向(GUI agent / 代码 agent / 记忆系统)读遍其顶会论文</li>
            <li>参与:给开源 agent 项目提 PR、把 MCP server 做成产品</li>
          </ul>
        </div>
      </div>

      <div className="card tip" style={{ marginTop: 24 }}>
        <span className="card-tag">时间不够?</span>
        精简版(4 周):周 1 = CH.01-05 + 项目①②合并;周 2 = CH.06-10 + 项目③;周 3 = CH.15-16 + 项目④;周 4 = CH.11-14/17-19 快速通读 + 毕业项目缩水版。代价是少踩的坑以后都会补回来——学习守恒定律。
      </div>
    </div>
  )
}
