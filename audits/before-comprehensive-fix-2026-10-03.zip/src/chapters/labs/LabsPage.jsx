import { useEffect, useState } from 'react'

import Overview from './overview.jsx'
import P1a from './p1a.jsx'
import P1b from './p1b.jsx'
import P1c from './p1c.jsx'
import P2a from './p2a.jsx'
import P2b from './p2b.jsx'
import P2c from './p2c.jsx'
import P3a from './p3a.jsx'
import P3b from './p3b.jsx'
import P3c from './p3c.jsx'
import { LABS } from './registry.js'

const KEYS = ['overview', ...LABS.map((l) => l.key)]

function readChecks() {
  try { return JSON.parse(localStorage.getItem('adg-quests') || '{}') } catch { return {} }
}

/* 实战工坊:总览 + 三个实战教学项目(页内切换,hash 可分享) */
export default function LabsPage() {
  const [active, setActive] = useState(() => {
    const h = window.location.hash
    const key = h.startsWith('#lab-') ? h.slice(5) : 'overview'
    return KEYS.includes(key) ? key : 'overview'
  })

  const go = (key) => {
    if (!KEYS.includes(key)) return
    setActive(key)
    window.history.replaceState(null, '', key === 'overview' ? '#lab' : `#lab-${key}`)
  }

  useEffect(() => {
    const onHash = () => {
      const h = window.location.hash
      const key = h.startsWith('#lab-') ? h.slice(5) : (h === '#lab' ? 'overview' : '')
      if (KEYS.includes(key)) setActive(key)
    }
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])

  useEffect(() => { window.scrollTo({ top: 0, behavior: 'instant' }) }, [active])

  // 各项目通关进度(勾选数),显示在标签上
  const checks = readChecks()
  const done = (lab) => {
    const set = new Set(checks[lab.qid] || [])
    return `${set.size}/${lab.quests.length}`
  }

  return (
    <div className="page">
      <div className="page-head">
        <div className="ch-meta">
          <span className="ch-level">SIDE QUEST</span>
          <span className="ch-mins">⏱ 教学建议每项目 2-3 周 · 🔨 3 个需集成与验证的实战项目</span>
        </div>
        <h2 className="ch-title">实战工坊</h2>
        <div className="ch-en">BUILD, INTEGRATE & EVALUATE — 3 AGENT ENGINEERING LABS</div>
      </div>

      <div className="toolbar lab-tabs">
        <button className={`chip ${active === 'overview' ? 'on' : ''}`} onClick={() => go('overview')}>
          📜 工坊大厅
        </button>
        {LABS.map((lab) => (
          <button key={lab.key} className={`chip ${active === lab.key ? 'on' : ''}`} onClick={() => go(lab.key)}>
            {lab.icon} {lab.code} {lab.title.split(' · ')[1]} <span className="cnt">{done(lab)}</span>
          </button>
        ))}
      </div>

      {active === 'overview' && <Overview onGo={go} />}
      {active === 'p1' && <><P1a /><P1b /><P1c onGo={go} /></>}
      {active === 'p2' && <><P2a /><P2b /><P2c onGo={go} /></>}
      {active === 'p3' && <><P3a /><P3b /><P3c onGo={go} /></>}
    </div>
  )
}
