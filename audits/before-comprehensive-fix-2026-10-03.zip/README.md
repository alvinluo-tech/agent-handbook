# AGENT 开发全指南 · 像素风互动手册

> From Zero to Agent Master —— 一本写给未来 Agent 工程师的中文互动手册。
> 目标:小白通关,行业大师存档。Version 1.1 · 内容核查快照 2026-10-03

## 这是什么

一个纯前端网站(React + Vite 脚手架初始化),包含:

- **19 章主线内容**:从「什么是 Agent」到 Agent Loop、上下文工程、Function Calling、MCP、沙箱、框架选型、记忆、RAG、规划、多智能体、Computer Use、代码智能体、Eval、安全、可观测性、协议生态、前沿雷达。内容对照 2025-2026 一线大厂公开实践(Anthropic / OpenAI / Google / 微软)与经典论文整理。
- **21 张原创像素风 SVG 图解**:主线与工坊的循环、频谱、时序、架构、拓扑、时间线、飞轮、路线图……
- **81 篇论文 + 2 份行业指南**:引用 83 份本地 PDF；磁盘共 84 份约 390.25MiB(含一个额外副本)，分 11 类。arXiv 元数据核验与技术事实核验分开进行。
- **68 个 GitHub 项目**:Star/更新时间为 API 采集快照，分 9 类附中文点评；已归档项目保留为历史参考，不宣称全部仍活跃。
- **3 个实战教学项目**:ATLAS、SCOUT、SENTINEL 提供架构、关键代码与评测设计；补齐依赖和集成后跟做，目标 KPI 与简历模板不是仓库实测成果。
- **互动系统**:通关清单 → LV/EXP 等级、可单步运行的 Agent 循环演示终端、scrollspy 侧边栏、移动端适配。

## 快速开始

```bash
npm install
npm run dev       # 开发:http://localhost:5173
npm run build     # 产物在 dist/(论文 PDF 在 dist/papers/)
npm run preview   # 本地预览构建产物
```

## 目录结构

```
agent-dev-guide/
├─ public/
│  ├─ papers/          # 83 份被引用 PDF；磁盘 84 份约 390.25MiB，按分类归档
│  └─ fonts/           # Press Start 2P + Fusion Pixel SC(本地托管)
├─ src/
│  ├─ chapters/        # 19 章内容 + 论文库/兵器谱/路线图/术语表页面
│  ├─ components/      # Bits(卡片/清单/终端) + Diag/Diag2(SVG 图解)
│  ├─ data/            # papers.json / projects.json + 自动生成的资源数量摘要
│  └─ styles.css       # 像素风设计系统
└─ tools/              # 数据管线脚本(Node,零依赖)
   ├─ papers.mjs       # arXiv 元数据校验 + PDF 批量下载归类
   ├─ gh-projects.mjs  # GitHub 仓库 Star/活跃度抓取
   ├─ gh-retry.mjs     # 限流重试与合并
   └─ fetch-*.mjs      # 字体下载
```

## 更新数据

```bash
node tools/papers.mjs        # 增量下载新论文(已有自动跳过),重生成 src/data/papers.json
node tools/gh-projects.mjs   # 重新抓取 GitHub 数据(未认证 60 次/小时,限流后用 gh-retry.mjs)
node tools/fetch-fusion.mjs  # 中文像素字体
```

新增论文:编辑 `tools/papers.mjs` 里的 `LIST`(arXiv ID + 分类),重跑即可;中文导读在 `src/chapters/PapersPage.jsx` 的 `NOTES`。

## 设计说明

- 像素风手册:硬边框 + 像素阴影 + 扫描线 + 「关卡 / 通关清单 / BOSS 提示」游戏化隐喻;全部 SVG 手绘,`shapeRendering: crispEdges`。
- 零运行时依赖:React + Vite 之外没有引入任何 UI 库;图解全部是手写 SVG 组件。

## 立场声明

内容为教学用途整理,引用均注明来源;Star 数与基准成绩随时间变化,以官方来源为准。论文版权归原作者/出版社,仅供学习研究。

## 时效维护与验证

2026-10-03 全篇更新覆盖模型、API 示例、协议时间线、框架维护状态与评测口径。详见 [官方来源](audits/update-sources-2026-10-03.md) 与 [更新验收记录](audits/update-completion-2026-10-03.md)。旧审计和 WORKLOG 保留为历史快照，不表示当前正文仍存在同样问题。

```bash
npm run lint
npm run build                     # 自动同步资源数量摘要
node tools/check-data.mjs
node tools/final-check.mjs
node tools/test-cost.mjs
node tools/check-examples.mjs      # 需 Python；语法与选定逻辑离线检查，不调用付费 API
node tools/audit-freshness.mjs     # 全篇候选句检索，须人工对照官方资料
```

首页数量来自 `src/data/resource-summary.json`，在开发和构建前生成。历史论文的模型、发表年份和原始实验保留，并注明版本及比较基线。费用需核对供应商、模型、端点与实际 usage；教程目标不能直接作为个人项目业绩。
